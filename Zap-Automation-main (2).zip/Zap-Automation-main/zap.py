from zapv2 import ZAPv2
from time import sleep
import os
from time import sleep
import subprocess
from requests.exceptions import ProxyError

#
zap = ZAPv2(proxies={'http': 'http://172.17.0.2:8090', 'https': 'http://172.17.0.2:8090'})


def do_some_zap_stuff(target):
	
	#Start zap scannings    
	print("opening target: " + target)
	try:
		zap.urlopen(target)
		sleep(2.5)
	except ProxyError:
		pass
	print("Starting spider scan")
	try:
		zap.spider.scan(target)
		while (int(zap.spider.status()) < 100):
			sleep(0.01)
	except ProxyError:
		pass
	print("Spider scan completed %: " + zap.spider.status())
	print("Starting Passive scan")
	try:
		while (int(zap.pscan.records_to_scan) > 0):
			sleep(0.01)
	except ProxyError:
		pass
	print("Passive scan completed %: 100")
	print("Starting active scan")
	try:
		zap.ascan.scan(target)
		sleep(2.5)
		while (int(zap.ascan.status()) < 100):
			sleep(0.01)
	except ProxyError:
		pass
	print("Active scan completed %: " + zap.ascan.status())
	print("Making report")

	#Saving report in json
	report_type = 'json'
	report_file = 'sample_report.json'
	with open(report_file, 'w') as f:
		json = zap.core.jsonreport()
		f.write(json)
		print('Success: {1} report saved to {0}'.format(report_file, report_type.upper())) 
	zap.core.shutdown()

def open_drivers(filename): 

	# Run scrape script
	command = "python3 scrape.py --file %s" % filename
	p = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
	(output, err) = p.communicate()
	p.wait()

	print("Running selenium script")
	#Run the saved script 
	command = "python3 selenium_script.py"
	p = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
	(output, err) = p.communicate()
	p.wait()

def zap_docker():
	
	print("Pulling zap docker image")
	#Pull the zap
	command = "sudo docker pull owasp/zap2docker-stable"
	p = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
	(output, err) = p.communicate()
	p.wait()

	print("Starting zap docker container")
	#run in detached mode
	command = "sudo docker run -d --rm -p 8090:8090 -i owasp/zap2docker-stable zap.sh -daemon -port 8090 -host 0.0.0.0 -config api.disablekey=true -config api.addrs.addr.name=.* -config api.addrs.addr.regex=true"
	p = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
	(output, err) = p.communicate()
	p.wait()


def zap_docker_kill():

	print("Stoping zap docker container")
	#To stop all dockers
	command = "sudo docker stop $(sudo docker ps -q)"
	p = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
	(output, err) = p.communicate()
	p.wait()

def remove_files():
	#Do housekeeping stuffs

	print("Removing files")
	#This will be quick so os.system()
	os.system("rm selenium_script.py")
	os.system("rm target.py")

def start(filname, target):
	zap_docker()
	sleep(10)
	open_drivers(filname)
	do_some_zap_stuff(target)
	zap_docker_kill()
	remove_files()


