

#Upload side file
curl -i -X PUT http://127.0.0.1:5000/api/side/upload --upload-file target.py

#Set target name
curl -s -X GET http://127.0.0.1:5000/api/set/target?name="http://testphp.vulnweb.com/userinfo.php"
