# Zap-Automation

## Workflow:

![Alt Text](https://i.ibb.co/xDXNH8W/Untitled-Diagram.jpg)

## How to test ? 

#### 1) Run install script

```
chmod +x install.sh
sudo ./install.sh 
```

#### 2) Start api.py

```
python3 api.py
```
#### 3) chmod u+x chromedriver

```
Get chromedriver from wget https://chromedriver.storage.googleapis.com/87.0.4280.88/chromedriver_linux64.zip
and then chmod u+x chromedriver
```
- Note: I fails to run the code make sure to download driver from here and add driver to this folder where  api.py is  npm install -g chromedriver, aslo make sure that chrome in installed in linux

#### 4) GO to example and run

```
bash send.sh
```





