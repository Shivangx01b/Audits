
#Install some essentials
apt-get -y install unzip
apt-get -y install python3-pip


#Install chrome
wget -q -O - https://dl-ssl.google.com/linux/linux_signing_key.pub | apt-key add - \
    && echo "deb http://dl.google.com/linux/chrome/deb/ stable main" >> /etc/apt/sources.list.d/google.list
apt-get update && apt-get -y install google-chrome-stable

#Add chromedriver #Make sure chrome version installed and driver version first 2 digits are same
wget https://chromedriver.storage.googleapis.com/87.0.4280.88/chromedriver_linux64.zip && unzip chromedriver_linux64.zip
#remove zip
rm chromedriver_linux64.zip

#install python modules
pip3 install -r requirements.txt
