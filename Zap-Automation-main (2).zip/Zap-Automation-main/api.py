from flask import Flask 
from flask import request
from flask import escape
from zap import start
import os 


app = Flask(__name__)

@app.route('/api/side/upload', methods=['PUT'])
def upload():
	
	#Store the python import file
	with open('target.py', 'wb') as filename:
		filename.write(request.data)
	filename.close()
	

	return 'Python imported succesfully'

@app.route('/api/set/target', methods=['GET'])
def target():

	#Setup targetname
	target = request.args.get('name')
	runner('target.py', escape(target))
	return 'All scan done... check report !'


def runner(filename, target):
	#pass
	#Call zap.py
	start(filename, target)

if __name__ == '__main__':
	print("Starting api for zap automation")
	app.run(host='0.0.0.0', port=5000, debug=True)

