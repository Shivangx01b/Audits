import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--file", help="Give python import path")
args = parser.parse_args()

filename = args.file

print("Scraping imported file")
contents = []
with open(filename, 'r') as file:
	for line in file:
		contents.append(line.strip('\n'))

scraped_codes = ""
for code in range(len(contents)):
	try:
		scraped_codes += contents[21 + int(code)].replace("self.", "").replace(' ', '') + "\n"
	except IndexError:
		pass


			
add_codes_above = """ 
import time
import json
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from xvfbwrapper import Xvfb
display = Xvfb()
display.start()
options = webdriver.ChromeOptions()
options.add_argument('--proxy-server=172.17.0.2:8090')
options.add_argument('--ignore-certificate-errors')
driver = webdriver.Chrome("chromedriver", options=options)
"""


add_codes_end = """
display.stop()
driver.quit()
"""


print("Adding codes")
with open("selenium_script.py", "w") as script:
	script.write(add_codes_above)
	script.write(scraped_codes)
	script.write(add_codes_end)
	script.close()

print("File saved !")
